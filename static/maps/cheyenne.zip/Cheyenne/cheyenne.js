
(function() {
	const api = window.SubwayBuilderAPI;

    // 1. Register city
	api.registerCity({
		name: 'Cheyenne',
		code: 'CYS',
		description: 'Cut through the countryside of Wyoming to serve the cities of Laramie and Cheyenne.',
		population: 52917,
		initialViewState: {
			zoom: 14,
			latitude: 41.149415,
			longitude: -104.821801,
			bearing: 0
		}
		
	});


	// 2. Set tile URLs
	api.map.setTileURLOverride({
		cityCode: 'CYS',
		tilesUrl: 'http://127.0.0.1:8080/CYS/{z}/{x}/{y}.mvt',
		foundationTilesUrl: 'http://127.0.0.1:8080/CYS/{z}/{x}/{y}.mvt',
		maxZoom: 15
	});

	// 3. Configure layers
	api.map.setLayerOverride({
		layerId: 'parks-large',
		sourceLayer: 'landuse',
		filter: ['==', ['get', 'kind'], 'park']
	});

// 4. Set data files
	api.cities.setCityDataFiles('CYS', {
		buildingsIndex: '/data/CYS/buildings_index.json.gz',
		demandData: '/data/CYS/demand_data.json.gz',
		roads: '/data/CYS/roads.geojson.gz',
		runwaysTaxiways: '/data/CYS/runways_taxiways.geojson.gz'
	});

// 5. Disable missing layers
	api.map.setDefaultLayerVisibility('CYS', {
		buildingFoundations: false,
		oceanFoundations: false
	});

})();


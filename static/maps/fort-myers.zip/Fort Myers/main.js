
(function() {
	const api = window.SubwayBuilderAPI;

    // 1. Register city
	api.registerCity({
		name: 'Fort Myers',
		code: 'RSW',
		description: 'Build railway bridges over the myriad canals of America`s Venice.',
		population: 229673,
		initialViewState: {
			zoom: 14,
			latitude: 26.647957,
			longitude: -81.878142,
			bearing: 0
		}
		
	});


	// 2. Set tile URLs
	api.map.setTileURLOverride({
		cityCode: 'RSW',
		tilesUrl: 'http://127.0.0.1:8080/RSW/{z}/{x}/{y}.mvt',
		foundationTilesUrl: 'http://127.0.0.1:8080/RSW/{z}/{x}/{y}.mvt',
		maxZoom: 15
	});

	// 3. Configure layers
	api.map.setLayerOverride({
		layerId: 'parks-large',
		sourceLayer: 'landuse',
		filter: ['==', ['get', 'kind'], 'park']
	});

// 4. Set data files
	api.cities.setCityDataFiles('RSW', {
		buildingsIndex: '/data/RSW/buildings_index.json.gz',
		demandData: '/data/RSW/demand_data.json.gz',
		roads: '/data/RSW/roads.geojson.gz',
		runwaysTaxiways: '/data/RSW/runways_taxiways.geojson.gz'
	});

// 5. Disable missing layers
	api.map.setDefaultLayerVisibility('RSW', {
		buildingFoundations: false,
		oceanFoundations: false
	});

})();



(function() {
	const api = window.SubwayBuilderAPI;
    // 1. Register city
	api.registerCity({
		name: 'Bismarck',
		code: 'BIS',
		description: 'Build a transit system worthy of one of America`s busiest metropolises.',
		population: 50745,
		initialViewState: {
			zoom: 13,
			latitude: 46.8089,
			longitude: -100.787,
			bearing: 0
		}
		
	});


	// 2. Set tile URLs
	api.map.setTileURLOverride({
		cityCode: 'BIS',
		tilesUrl: 'http://127.0.0.1:8080/BIS/{z}/{x}/{y}.mvt',
		foundationTilesUrl: 'http://127.0.0.1:8080/BIS/{z}/{x}/{y}.mvt',
		maxZoom: 15
	});

	// 3. Configure layers
	api.map.setLayerOverride({
		layerId: 'parks-large',
		sourceLayer: 'landuse',
		filter: ['==', ['get', 'kind'], 'park']
	});

// 4. Set data files
	api.cities.setCityDataFiles('BIS', {
		buildingsIndex: '/data/BIS/buildings_index.json.gz',
		demandData: '/data/BIS/demand_data.json.gz',
		roads: '/data/BIS/roads.geojson.gz',
		runwaysTaxiways: '/data/BIS/runways_taxiways.geojson.gz'
	});

// 5. Disable missing layers
	api.map.setDefaultLayerVisibility('BIS', {
		buildingFoundations: false,
		oceanFoundations: false
	});

})();


